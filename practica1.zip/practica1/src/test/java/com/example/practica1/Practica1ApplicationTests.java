package com.example.practica1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
